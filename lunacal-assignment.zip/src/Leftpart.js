import React from 'react'
import './App.css'
export default function Leftpart() {
  return (
    <div className='left'>
        
    </div>
  )
}
