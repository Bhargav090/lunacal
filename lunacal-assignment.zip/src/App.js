import './App.css';
import Leftpart from './Leftpart';
import Rightpart from './Rightpart';

function App() {
  return (
    <div className="App">
      <Leftpart />
      <Rightpart />
    </div>
  );
}

export default App;
