import React from "react";

export default function Recommended() {
  return (
    <div>
      Duis sapien sem, aliquet nec, commodo eget, consequat quis, neque. Aliquam
      faucibus, elit ut dictum aliquet, felis nisl adipiscing sapien, sed
      malesuada diam lacus eget erat. Cras mollis scelerisque nunc. Nullam arcu.
      Aliquam consequat. Curabitur augue lorem, dapibus quis, laoreet et,
      pretium ac, nisi. Aenean magna nisl, mollis quis, molestie eu, feugiat in,
      orci. In hac habitasse platea dictumst.
    </div>
  );
}
